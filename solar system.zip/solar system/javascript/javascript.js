window.onload=start1

function start1()
{alert("You are at Mercury");
document.getElementById("m1").value="";
document.getElementById("m2").value="";
document.getElementById("mcalc").onclick=mcalc
document.getElementById("m1").value="";
document.GetElementById("m2").value="";}
function start2()
{document.getElementById("m1").value="";
document.getElementById("m2").value="";
document.getElementById("mcalc").onclick=mcalc
document.getElementById("m1").value="";
document.GetElementById("m2").value="";}

/*Mercury*/
function mercury1()
{document.getElementById("mercury").src='images/insidemercury.jpg';}
function mercury2()
{document.getElementById("mercury").src='images/mercury.png';}

function mcalc()
{var x = document.getElementById("m1").value;
var y = x * 2.36;
document.getElementById("m2").value=y;}