window.onload=start1

function start1()
{alert("You are at Pluto");
document.getElementById("p1").value="";
document.getElementById("p2").value="";
document.getElementById("pcalc").onclick=pcalc
document.getElementById("p1").value="";
document.GetElementById("p2").value="";}
function start2()
{document.getElementById("p1").value="";
document.getElementById("p2").value="";
document.getElementById("pcalc").onclick=pcalc
document.getElementById("p1").value="";
document.GetElementById("p2").value="";}

/*Mercury*/
function pluto1()
{document.getElementById("pluto").src='images/insidepluto.jpg';}
function pluto2()
{document.getElementById("pluto").src='images/pluto.png';}

function pcalc()
{var x = document.getElementById("p1").value;
var y = x * .07;
document.getElementById("p2").value=y;}