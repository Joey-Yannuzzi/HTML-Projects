window.onload=start1

function start1()
{alert("You are at Jupiter");
document.getElementById("j1").value="";
document.getElementById("j2").value="";
document.getElementById("jcalc").onclick=jcalc
document.getElementById("j1").value="";
document.GetElementById("j2").value="";}
function start2()
{document.getElementById("j1").value="";
document.getElementById("j2").value="";
document.getElementById("jcalc").onclick=jcalc
document.getElementById("j1").value="";
document.GetElementById("j2").value="";}

/*Jupiter*/
function jupiter1()
{document.getElementById("jupiter").src='images/insidejupiter.jpg';}
function jupiter2()
{document.getElementById("jupiter").src='images/jupiter.png';}

function jcalc()
{var x = document.getElementById("j1").value;
var y = x * 2.36;
document.getElementById("j2").value=y;}