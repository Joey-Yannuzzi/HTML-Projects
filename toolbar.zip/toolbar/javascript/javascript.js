/*Pokemon Red*/
function over1()
{document.getElementById("red").src='images/mewtwo.png';}
function out1()
{document.getElementById("red").src='images/red.png';}
function click1()
{document.getElementById("red").src='images/charizard.png';}

/*Pokemon Blue*/
function over2()
{document.getElementById("blue").src='images/mewtwo.png';}
function out2()
{document.getElementById("blue").src='images/blue.jpg';}
function click2()
{document.getElementById("blue").src='images/blastoise.png';}

/*Pokemon Yellow*/
function over3()
{document.getElementById("yellow").src='images/mewtwo.png';}
function out3()
{document.getElementById("yellow").src='images/yellow.jpg';}
function click3()
{document.getElementById("yellow").src='images/pikachu.png';}

/*Pokemon Green*/
function over4()
{document.getElementById("green").src='images/mewtwo.png';}
function out4()
{document.getElementById("green").src='images/green.jpg';}
function click4()
{document.getElementById("green").src='images/venusaur.png';}


/*Pokemon Silver*/
function over5()
{document.getElementById("silver").src='images/lugia.png';}
function out5()
{document.getElementById("silver").src='images/silver.png';}
function click5()
{document.getElementById("silver").src='images/meganium.png';}

/*Pokemon Gold*/
function over6()
{document.getElementById("gold").src='images/ho-oh.png';}
function out6()
{document.getElementById("gold").src='images/gold.png';}
function click6()
{document.getElementById("gold").src='images/typhosion.png';}

/*Pokemon Crystal*/
function over7()
{document.getElementById("crystal").src='images/suicune.png';}
function out7()
{document.getElementById("crystal").src='images/crystal.png';}
function click7()
{document.getElementById("crystal").src='images/feraligatr.png';}



/*Pokemon Ruby*/
function over8()
{document.getElementById("ruby").src='images/groudon.png';}
function out8()
{document.getElementById("ruby").src='images/ruby.png';}
function click8()
{document.getElementById("ruby").src='images/blaziken.png';}

/*Pokemon Sapphire*/
function over9()
{document.getElementById("sapphire").src='images/kyogre.png';}
function out9()
{document.getElementById("sapphire").src='images/sapphire.png';}
function click9()
{document.getElementById("sapphire").src='images/swampert.png';}

/*Pokemon Emerald*/
function over10()
{document.getElementById("emerald").src='images/rayquaza.png';}
function out10()
{document.getElementById("emerald").src='images/emerald.jpg';}
function click10()
{document.getElementById("emerald").src='images/sceptile.png';}



/*Pokemon Diamond*/
function over11()
{document.getElementById("diamond").src='images/dialga.png';}
function out11()
{document.getElementById("diamond").src='images/diamond.png';}
function click11()
{document.getElementById("diamond").src='images/empoleon.png';}