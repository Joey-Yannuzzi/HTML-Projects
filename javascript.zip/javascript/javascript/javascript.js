    function mouse()
	{document.getElementById("pic").src='images/luna.jpg';
	document.getElementById("name").innerHTML='Moon';}
	function out()
	{document.getElementById("pic").src='images/sol.png';
	document.getElementById("name").innerHTML='Sun';}