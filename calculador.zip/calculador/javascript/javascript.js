window.onload=start;

function start()
{document.getElementById("ans").value="";
document.getElementById("v1").value="";
document.getElementById("v2").value="";
document.getElementById("add").onclick=add;
document.getElementById("subtract").onclick=subtract;
document.getElementById("multiply").onclick=multiply;
document.getElementById("divide").onclick=divide;}

function add()
{var x = document.getElementById("v1").value;
var y = document.getElementById("v2").value;
var z = Number(x) + Number(y);
document.getElementById("ans").value=z;}

function subtract()
{var x = document.getElementById("v1").value;
var y = document.getElementById("v2").value;
var z = x - y ;
document.getElementById("ans").value=z;}

function multiply()
{var x = document.getElementById("v1").value;
var y = document.getElementById("v2").value;
var z = x * y ;
document.getElementById("ans").value=z;}

function divide()
{var x = document.getElementById("v1").value;
var y = document.getElementById("v2").value;
var z = x / y ;
if (y = 0)
{document.getElementById("ans").value="Undefined"}
else
{
document.getElementById("ans").value=z;}
}
