/*triggers function "start()"*/
window.onload=start;

/*triggers function "setdate()"*/ 
function start()
{setdate()}

/*sets date*/
function setdate()
{var thedate = new Date()
var hour
var time
var month
var day
var minute
var milhour = thedate.getHours()
var second
if (thedate.getMinutes() < 10)
{minute = "0" + thedate.getMinutes()}
else
{minute = thedate.getMinutes()}
if (thedate.getSeconds() < 10)
{second = "0" + thedate.getSeconds()}
else
{second = thedate.getSeconds()}
if (thedate.getHours() > 12)
{hour = Number(thedate.getHours()) - 12;
time = "PM"}
else
{hour = thedate.getHours}
if (thedate.getMonth() == 0)
{month = "January"}
if (thedate.getMonth() == 1)
{month = "Febuary"}
if (thedate.getMonth() == 2)
{month = "March"}









if (thedate.getDay() == 0)
{day = "sunday"}
if (thedate.getDay() == 1)
{day = "Monday"}
if (thedate.getDay() == 2)
{day = "Tuesday"}
if (thedate.getDay() == 3)
{day = "Wednesday"}
if (thedate.getDay() == 4)
{day = "Thursday"}
if (thedate.getDay() == 5)
{day = "Friday"}
if (thedate.getDay() == 6)
{day = "Saturday"}
if (milhour >= 11 && milhour <= 13)
{document.getElementById("greeting").innerHTML= "Good Day";}
if (milhour >= 5 && milhour <= 7)
{document.getElementById("greeting").innerHTML= "Good Morning";}
if (milhour >= 17 && milhour <= 19)
{document.getElementById("greeting").innerHTML= "Good Afternoon";}
if (milhour >= 22)
{document.getElementById("greeting").innerHTML= "Good Night";}
document.getElementById("thedate").innerHTML= day + "," + " " + month + " " + thedate.getDate() + "," + " " + thedate.getFullYear() + "<br>" + hour + ":" + minute + ":" + second + " " + time
setTimeout (function() {setdate()},1);}


/*Toolbar*/
function cracked()
{document.getElementById("cracked1").style.width='200px';
responsiveVoice.speak('Contact Us');}
function cracked2()
{document.getElementById("cracked1").style.width='100px';}

function LCD()
{document.getElementById("LCD2").style.width='200px';
responsiveVoice.speak('Membership Discounts');}
function LCQ()
{document.getElementById("LCD2").style.width='100px';}

function SD()
{document.getElementById("SD1").style.width='200px';
responsiveVoice.speak('Order Now!');}
function SD2()
{document.getElementById("SD1").style.width='100px';}