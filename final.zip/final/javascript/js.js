window.onload=popup();

function popup()
{alert('You are on the Characters website!');}
function linkover()
{document.getElementById("link").src='images/link2.png';}
function linkout()
{document.getElementById("link").src='images/link.png';}
function linkclick()
{document.getElementById("link").src='images/link3.png';}

function zeldaover()
{document.getElementById("zelda").src='images/zelda3.png';}
function zeldaout()
{document.getElementById("zelda").src='images/zelda.png';}
function zeldaclick()
{document.getElementById("zelda").src='images/sheik.png';}

function gannonover()
{document.getElementById("gannon").src='images/gannon2.png';}
function gannonout()
{document.getElementById("gannon").src='images/ganon.png';}
function gannonclick()
{document.getElementById("gannon").src='images/gannon3.png';}

function chest1()
{document.getElementById("chest1").innerHTML='Hey!  Listen, the musical instament may have some use!';}