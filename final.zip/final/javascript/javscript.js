/*triggers function "start()"*/
window.onload=start;

/*triggers function "setdate()"*/ 
function start()
{setdate()}

/*sets date*/
function setdate()
{var thedate = new Date()
var hour
var time
var month
var day
var minute
var milhour = thedate.getHours()
var second
if (thedate.getMinutes() < 10)
{minute = "0" + thedate.getMinutes()}
else
{minute = thedate.getMinutes()}
if (thedate.getSeconds() < 10)
{second = "0" + thedate.getSeconds()}
else
{second = thedate.getSeconds()}
if (thedate.getHours() > 12)
{hour = Number(thedate.getHours()) - 12;
time = "PM"}
else
{hour = thedate.getHours}
if (thedate.getMonth() == 0)
{month = "January"}
if (thedate.getMonth() == 1)
{month = "Febuary"}
if (thedate.getMonth() == 2)
{month = "March"}









if (thedate.getDay() == 0)
{day = "sunday"}
if (thedate.getDay() == 1)
{day = "Monday"}
if (thedate.getDay() == 2)
{day = "Tuesday"}
if (thedate.getDay() == 3)
{day = "Wednesday"}
if (thedate.getDay() == 4)
{day = "Thursday"}
if (thedate.getDay() == 5)
{day = "Friday"}
if (thedate.getDay() == 6)
{day = "Saturday"}
document.getElementById("thedate").innerHTML= day + "," + " " + month + " " + thedate.getDate() + "," + " " + thedate.getFullYear() + "<br>" + hour + ":" + minute + ":" + second + " " + time
setTimeout (function() {setdate()},1);}